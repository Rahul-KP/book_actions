document.getElementById('add_button').addEventListener('click',function(){
	var row = document.createElement('tr');
	var name = document.createElement('td');
	var number = document.createElement('td');

	name.innerText = document.getElementById('name').value;
	number.innerText = document.getElementById('number').value;

	row.appendChild(name);
	row.appendChild(number);

	document.getElementById('table').appendChild(row);
})